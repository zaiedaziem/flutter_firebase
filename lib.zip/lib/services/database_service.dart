import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/todo.dart';

const String TODO_COLLECTION_REF = "todos";

class DatabaseService {
  final _firestore = FirebaseFirestore.instance;
  final _auth = FirebaseAuth.instance;

  late final CollectionReference _todosRef;

  DatabaseService() {
    _todosRef = _firestore.collection(TODO_COLLECTION_REF).withConverter<Todo>(
          fromFirestore: (snapshot, _) => Todo.fromJson(snapshot.data()!),
          toFirestore: (todo, _) => todo.toJson(),
        );
  }

  // Get current user's ID
  String? get _currentUserId => _auth.currentUser?.uid;

  // Get todos for the current user only
  Stream<QuerySnapshot> getTodos() {
    if (_currentUserId == null) {
      throw Exception('User not authenticated');
    }
    
    return _todosRef
        .where('userId', isEqualTo: _currentUserId)
        .orderBy('updatedOn', descending: true)
        .snapshots();
  }

  // Add todo for the current user
  void addTodo(Todo todo) async {
    if (_currentUserId == null) {
      throw Exception('User not authenticated');
    }
    
    // Add userId to the todo before saving
    Map<String, dynamic> todoData = todo.toJson();
    todoData['userId'] = _currentUserId;
    
    _todosRef.add(todoData);
  }

  // Update todo (only if it belongs to current user)
  void updateTodo(String todoId, Todo todo) async {
    if (_currentUserId == null) {
      throw Exception('User not authenticated');
    }
    
    // Verify the todo belongs to the current user before updating
    DocumentSnapshot doc = await _todosRef.doc(todoId).get();
    if (doc.exists) {
      Map<String, dynamic>? data = doc.data() as Map<String, dynamic>?;
      if (data?['userId'] == _currentUserId) {
        Map<String, dynamic> todoData = todo.toJson();
        todoData['userId'] = _currentUserId;
        _todosRef.doc(todoId).update(todoData);
      } else {
        throw Exception('Unauthorized: Cannot update todo that belongs to another user');
      }
    }
  }

  // Delete todo (only if it belongs to current user)
  void deleteTodo(String todoId) async {
    if (_currentUserId == null) {
      throw Exception('User not authenticated');
    }
    
    // Verify the todo belongs to the current user before deleting
    DocumentSnapshot doc = await _todosRef.doc(todoId).get();
    if (doc.exists) {
      Map<String, dynamic>? data = doc.data() as Map<String, dynamic>?;
      if (data?['userId'] == _currentUserId) {
        _todosRef.doc(todoId).delete();
      } else {
        throw Exception('Unauthorized: Cannot delete todo that belongs to another user');
      }
    }
  }

  // Delete all todos for the current user (useful for account deletion)
  Future<void> deleteAllUserTodos() async {
    if (_currentUserId == null) {
      throw Exception('User not authenticated');
    }
    
    QuerySnapshot todos = await _todosRef
        .where('userId', isEqualTo: _currentUserId)
        .get();
    
    WriteBatch batch = _firestore.batch();
    for (DocumentSnapshot doc in todos.docs) {
      batch.delete(doc.reference);
    }
    
    await batch.commit();
  }
}